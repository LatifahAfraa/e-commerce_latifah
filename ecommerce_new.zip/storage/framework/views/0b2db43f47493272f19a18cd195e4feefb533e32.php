<!doctype html>
<html lang="en" class="h-100">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="description" content="">
  <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
  <meta name="generator" content="Hugo 0.84.0">
  <title>User List</title>

  <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/sticky-footer/">



  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(url('../assets')); ?>/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    .bd-placeholder-img {
      font-size: 1.125rem;
      text-anchor: middle;
      -webkit-user-select: none;
      -moz-user-select: none;
      user-select: none;
    }

    @media (min-width: 768px) {
      .bd-placeholder-img-lg {
        font-size: 3.5rem;
      }
    }
  </style>


  <!-- Custom styles for this template -->
  <link href="<?php echo e(url('../assets')); ?>/css/sticky-footer.css" rel="stylesheet">
</head>

<body>

  <!-- Begin page content -->
  <div class="container-fluid">

    <header class="d-flex p-3">
      <button type="button" class="btn align-self-center me-4">
        <i data-feather="chevron-left"></i>
      </button>
      <div class="pt-1 mx-auto">
        <h2 class="text-center">User List</h2>
      </div>
    </header>

<div class="form-group">
  <div class="row  justify-content-center">
    <div class="col-md-6 ">
      <div class="card  ">
        <div class="card-body d-flex">
          <div class="me-3">
            <img src="https://www.011global.com/Account/Slices/user-anonymous.png" alt="" srcset="" class="img-fluid"  width="75px" >
          </div>

            <div>
              <h4 class="mb-0">Steve Job</h4>
              <p>steve@uapps.id</p>
            </div>
        </div>
      </div>
    </div>
  </div>

  </div>

  </div>
  <div class="d-flex bd-highlight mb-5 mt-5" style="position: fixed; left:82%; width:max-content; bottom:10%;">
    <button type="button" class="btn btn-primary rounded-circle p-2">
      <i data-feather="plus-circle"></i>
    </button>
  </div>

  <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js"
    integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE"
    crossorigin="anonymous"></script>
  <script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js"
    integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha"
    crossorigin="anonymous"></script>
  <script src="<?php echo e(url('../assets')); ?>/js/dashboard.js"></script>

</body>

</html>
<?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/layouts/user_list.blade.php ENDPATH**/ ?>