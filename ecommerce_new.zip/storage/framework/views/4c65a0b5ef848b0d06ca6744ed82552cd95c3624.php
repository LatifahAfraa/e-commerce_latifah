
    <header class="navbar sticky-top bg-white flex-md-nowrap p-0 ">
        <img class="mb-4 mx-auto d-block" src="<?php echo e(url('../assets')); ?>/img/Logo.png" alt="" width="100px">
        <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
            data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false"
            aria-label="Toggle navigation">
            <i class="fa fa-bars"></i>
        </button>
    </header>
<?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/layouts/header.blade.php ENDPATH**/ ?>