
    <header class="d-flex p-3">
        <button type="button" class="btn align-self-center me-4" onclick="history.back()">
          <i data-feather="chevron-left"></i>
        </button>
        <div class="pt-1 mx-auto">
          <h2 class="text-center"><?php echo e($text ?? "User List"); ?></h2>
        </div>
      </header>
<?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/layouts/header-back.blade.php ENDPATH**/ ?>