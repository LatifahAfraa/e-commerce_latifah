<!doctype html>
<html lang="en" class="h-100">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="Mark Otto, Jacob Thornton, and Bootstrap contributors">
    <meta name="generator" content="Hugo 0.84.0">
    <title>Home</title>

    <link rel="canonical" href="https://getbootstrap.com/docs/5.0/examples/sticky-footer-navbar/">



    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(url('../assets')); ?>/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css" integrity="sha512-xh6O/CkQoPOWDdYTDqeRdPCVd1SpvCA9XXcUnZS2FmJNp1coAFzvtCN9BmamE+4aHK8yyUHUSCcJHgXloTyT2A==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <style>
        .bd-placeholder-img {
            font-size: 1.125rem;
            text-anchor: middle;
            -webkit-user-select: none;
            -moz-user-select: none;
            user-select: none;
        }

        @media (min-width: 768px) {
            .bd-placeholder-img-lg {
                font-size: 3.5rem;
            }
        }
    </style>


    <!-- Custom styles for this template -->
    <link href="<?php echo e(url('../assets')); ?>/css/sticky-footer-navbar.css" rel="stylesheet">
</head>

<body>
    <div class="d-flex flex-column h-100">
        <header class="navbar sticky-top bg-white flex-md-nowrap p-0 ">
            <img class="mb-4 mx-auto d-block" src="<?php echo e(url('../assets')); ?>/img/Logo.png" alt="" width="100px">
            <button class="navbar-toggler position-absolute d-md-none collapsed" type="button" data-bs-toggle="collapse"
                data-bs-target="#sidebarMenu" aria-controls="sidebarMenu" aria-expanded="false"
                aria-label="Toggle navigation">
                <i class="fa fa-bars"></i>
            </button>
        </header>

        <!-- Begin page content -->
        <div class="container-fluid" style="padding-bottom: 200px !important;">
            <div class="row">
                <nav id="sidebarMenu" class="col-md-3 col-lg-2 d-md-block bg-white sidebar collapse">
                    <div class="position-sticky pt-3">
                        <ul class="nav flex-column">
                            <li class="nav-item">
                                <a class="nav-link active" aria-current="page" href="#">
                                    <span data-feather="users"></span>
                                    User List
                                </a>
                            </li>
                            <li class="nav-item">
                                <a class="nav-link" href="#">
                                    <span data-feather="log-out"></span>
                                    Logout
                                </a>
                            </li>
                        </ul>
                    </div>
                </nav>

                <main class="col-md-9 ms-sm-auto col-lg-10 px-md-4">
                    <div
                        class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
                        <input class="form-control form-control-dark w-100" type="text" placeholder="Search"
                            aria-label="Search">
                    </div>
                    <div id="myCarousel" class="carousel slide" data-bs-ride="carousel">
                        <div class="carousel-indicators">
                            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="0" class="active"
                                aria-current="true" aria-label="Slide 1"></button>
                            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="1"
                                aria-label="Slide 2"></button>
                            <button type="button" data-bs-target="#myCarousel" data-bs-slide-to="2"
                                aria-label="Slide 3"></button>
                        </div>
                        <div class="carousel-inner">
                            <div class="carousel-item active">
                                <img src="https://cottondna.com/vendor/designer/admin/assets/img/default-cover.png"
                                    class="img-fluid" alt="" height="50%">
                                <div class="container">
                                    <div class="carousel-caption text-start">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#myCarousel"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#myCarousel"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>

                    <div class="row row-cols-1 row-cols-sm-3 row-cols-md-3 mt-3 g-3">
                        <div class="col">
                            <div class="card bg-light">
                                <center><i class="fa-solid fa-gift mt-3"></i></center>
                                <p href="" class=" text-center">Material</p>
                            </div>
                        </div>

                        <div class="col">
                            <div class="card bg-light">
                                <center><i class="fa-solid fa-wrench mt-3"></i></center>
                                <p href="" class=" text-center">Tools</p>
                            </div>
                        </div>


                        <div class="col">
                            <div class="card bg-light">
                                <center><i class="fa-solid fa-hill-rockslide mt-3"></i></center>
                                <p href="" class=" text-center">Fitting</p>
                            </div>
                        </div>

                        <div class="col">
                            <div class="card bg-light">

                                <center><i class="fa-solid fa-images mt-3"></i>
                                </center>
                                <p href="" class=" text-center">Ceramics</p>
                            </div>
                        </div>

                        <div class="col">
                            <div class="card bg-light">
                                <center><i class="fa-solid fa-layer mt-3"></i></center>
                                <p href="" class=" text-center">Acrylic</p>
                            </div>
                        </div>

                        <div class="col">
                            <div class="card bg-light">
                                <center><i  class="fa fa-shapes mt-3"></i></center>
                                <p href="" class=" text-center">Other</p>
                            </div>
                        </div>

                    </div>
                </main>

            </div>
        </div>
    </div>

    <?php echo $__env->make("layouts.footer", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <script src="<?php echo e(url('../assets')); ?>/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/js/all.min.js" integrity="sha512-naukR7I+Nk6gp7p5TMA4ycgfxaZBJ7MO5iC3Fp6ySQyKFHOGfpkSZkYVWV5R7u7cfAicxanwYQ5D1e17EfJcMA==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <script src="https://cdn.jsdelivr.net/npm/feather-icons@4.28.0/dist/feather.min.js" integrity="sha384-uO3SXW5IuS1ZpFPKugNNWqTZRRglnUJK6UAZ/gxOX80nxEkN9NcGZTftn6RzhGWE" crossorigin="anonymous"></script><script src="https://cdn.jsdelivr.net/npm/chart.js@2.9.4/dist/Chart.min.js" integrity="sha384-zNy6FEbO50N+Cg5wap8IKA4M/ZnLJgzc6w2NqACZaK0u0FXfOWRRJOnQtpZun8ha" crossorigin="anonymous"></script><script src="<?php echo e(url('../assets')); ?>/js/dashboard.js"></script>


</body>

</html>
<?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/layouts/home.blade.php ENDPATH**/ ?>