<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header-back', ['text' => "User List"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container-fluid" style="padding-bottom: 100px !important;">
  <div class="row  justify-content-center">
    <div class="col-md-6 ">
        <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card my-1 ">
        <div class="card-body d-flex">
          <div class="me-3">
            <img src="https://www.011global.com/Account/Slices/user-anonymous.png" alt="" srcset="" class="img-fluid"  width="75px" >
          </div>

            <div>
                <h4 class="text-center mb-0"><?php echo e($item->name ?? ''); ?></h4>
                <p><?php echo e($item->email ?? ''); ?></p>
            </div>
        </div>
      </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

  </div>

  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/pages/user_list.blade.php ENDPATH**/ ?>