<?php $__env->startSection('content'); ?>
<?php echo $__env->make('layouts.header-back', ['text' => "My Account"], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="text-center mt-4">
        <img src="https://www.011global.com/Account/Slices/user-anonymous.png" alt="" srcset="" class="img-fluid"
            width="150px">
        <h4 class="text-center mb-0"><?php echo e(auth()->user()->name ?? ''.last_name ?? ''); ?></h4>
        <p><?php echo e(auth()->user()->email ?? ''); ?></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\LARAVEL\ecommerce_new\resources\views/pages/account.blade.php ENDPATH**/ ?>